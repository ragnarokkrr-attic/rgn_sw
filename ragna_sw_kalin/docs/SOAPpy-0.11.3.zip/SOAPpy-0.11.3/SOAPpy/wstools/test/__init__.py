#! /usr/bin/env python
"""wstools.WSDLTools.WSDLReader tests directory."""

import utils

