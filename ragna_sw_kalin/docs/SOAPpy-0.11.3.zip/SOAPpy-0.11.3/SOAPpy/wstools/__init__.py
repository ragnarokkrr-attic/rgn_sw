#! /usr/bin/env python
"""WSDL parsing services package for Web Services for Python."""

ident = "$Id: __init__.py,v 1.5 2003/07/22 14:54:32 warnes Exp $"

import WSDLTools
import XMLname

